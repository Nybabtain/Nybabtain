import tkinter
from tkinter import messagebox
import uuid
import re
from datetime import datetime
from SetSql import *


conn = GetConn()

class signUp:
    def __init__(self):


        self.window = tkinter.Tk()
        self.window.title("Sign up")
        self.window.geometry('800x800')
        self.window.geometry("+600+200") # to position the window in the center
        self.window.configure(bg = '#ADADAD')
        self.window.iconphoto(False,tkinter.PhotoImage(file='smallLOGO.png'))

        self.canv = tkinter.Canvas( width=200,height=200 ,bg="#ADADAD",highlightbackground="#ADADAD")
        self.img = tkinter.PhotoImage(file='KSU.png')
        self.canv.create_image(100,100, image=self.img)
        self.canv.pack()

        # First Text
        self.lblMain = tkinter.Label(self.window, text="KSUPay", font=('Helvetica', 16, 'bold'),bg = '#ADADAD')
        self.lblMain.pack()

        # first Name
        # Label
        self.lblFirst = tkinter.Label(self.window, text="First Name",bg = '#ADADAD')
        self.lblFirst.pack()

        # Form
        self.txtFirst = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtFirst.pack()

        # last Name
        # Label
        self.lblLast = tkinter.Label(self.window, text="Last Name",bg = '#ADADAD')
        self.lblLast.pack()

        # Form
        self.txtLast = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtLast.pack()

        # ID
        # Label
        self.lblID = tkinter.Label(self.window, text="ID",bg = '#ADADAD' )
        self.lblID.pack()
        # Form
        self.txtID = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtID.pack()

        # Password
        # Label
        self.lblPass = tkinter.Label(self.window, text="Password",bg = '#ADADAD' )
        self.lblPass.pack()
        # Form
        self.txtPass = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtPass.pack()

        # Email address
        # Label
        self.lblMail = tkinter.Label(self.window, text="Email address",bg = '#ADADAD')
        self.lblMail.pack()
        # Form
        self.txtMail = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtMail.pack()
        # Phone
        # Label
        self.lblPhone = tkinter.Label(self.window, text="Phone",bg = '#ADADAD')
        self.lblPhone.pack()
        # Form
        self.txtPhone = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtPhone.pack()




        #submit button which is the sign up button
        self.buttonSubmit = tkinter.Button(self.window, text='Submit', command=self.check,bg = '#4F94CD')
        #Log in button
        self.buttonLogin = tkinter.Button(self.window, text='Login', command=self.go_Login ,bg = '#4F94CD')

        self.buttonSubmit.pack()
        self.buttonLogin.pack()

        self.window.mainloop()

    def validation(self):
        error_msg = ""
        if not self.txtFirst.get().replace(" ", "").isalpha():
            error_msg += "First name must be all letters\n"
        if len(self.txtFirst.get()) < 1:
            error_msg += "First name cant be empty \n"

        if not self.txtLast.get().replace(" ", "").isalpha():
            error_msg += "Last name must be all letters\n"
        if len(self.txtLast.get()) < 1:
            error_msg += "Last name cant be empty \n"


        if len(self.txtID.get()) != 10:
            error_msg += "ID must 10 digits\n"
        if len(self.txtID.get()) < 1:
            error_msg += "ID cant be empty \n"
        if not self.txtID.get().isnumeric():
            error_msg += "ID must be all digits\n"

        if self.txtPass.get().isalpha() or self.txtPass.get().isnumeric() :
            if len(self.txtPass.get()) < 6:
                error_msg += "Password must at leats 6 digits or letters\n"
            if len(self.txtPass.get()) < 1:
                error_msg += "Password cant be empty \n"
        else:
            error_msg += "Password must be all letters or digits\n"

        regex = "^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w+[.]\w{2}$'"
        if not (re.search(regex, self.txtMail.get())):
             print(self.txtMail.get())
             if not self.txtMail.get().lower().endswith('@ksu.edu.sa'):
                error_msg += "Email must be at this format (*******@ksu.edu.sa)\n"

        if len(self.txtMail.get()) < 1:
            error_msg += "Email cant be empty \n"

        if len(self.txtMail.get()) < 12:
            error_msg += "Email cant be at this format \n"

        if not self.txtPhone.get().startswith('05'):
            error_msg += "Phone must start with 05********\n"
        if not self.txtPhone.get().isnumeric():
            error_msg += "Phone must be all digits\n"
        if len(self.txtPhone.get()) != 10:
            error_msg += "Phone must 10 digits\n"
        if len(self.txtPhone.get()) < 1:
            error_msg += "Phone cant be empty \n"

        if error_msg == "":
            UUID = uuid.uuid1()
            self.tempWalletNum = int(UUID.time_low)
            self.tempBalance = 1000

            # this before orgnaize and with microsecond
            now = datetime.now()
            # dd/mm/YY H:M:S without microseconds
            self.tempDate = now.strftime("%d/%m/%Y %H:%M:%S")

            self.put()
            self.go_Login()

            self.txtFirst.delete(0, "end")
            self.txtLast.delete(0, "end")
            self.txtID.delete(0, "end")
            self.txtPass.delete(0, "end")
            self.txtMail.delete(0, "end")
            self.txtPhone.delete(0, "end")
        else:
            tkinter.messagebox.showerror('Wrong input', error_msg)
    def go_Login(self):
        self.window.destroy()
        import logIn
        logIn.logIn()
    def check(self):
        tempID = self.txtID.get()
        if  self.txtID.get().isnumeric():
            if  tempID :
                p = "SELECT ID FROM PERSON WHERE ID = " + str(tempID) + ";"
                print(p)
                cur = conn.cursor()
                cur.execute(p)
                records = cur.fetchall()
                print(records)
                if  len(records)==0:
                    self.validation()
                else:
                    error = "You are already registered"
                    tkinter.messagebox.showerror('Wrong input', error)
            else:
                self.validation()
        else:
            error_msg = "ID must be all digits\n"
            tkinter.messagebox.showerror('Wrong input', error_msg)

    def put(self):
        cur = conn.cursor()
        q = 'INSERT INTO PERSON (FIRSTNAME,LASTNAME,ID,PASSWORD,EMAIL,PHONE,WALLETNUM,BALANCE,DATEANDTIME,WALLETTYPE) VALUES ("'
        q+=self.txtFirst.get() +'","' +self.txtLast.get()+'","'+self.txtID.get()+'","'+ self.txtPass.get()+'","'+ self.txtMail.get()+'","'+ self.txtPhone.get()+'","'+str(self.tempWalletNum )+'","'+ str(self.tempBalance) +'","'+self.tempDate+'","'+ "student" + '")'
        print(q)

        cur.execute(q)
        cur.close()
        conn.commit()



signUp()
