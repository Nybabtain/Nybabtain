import tkinter
from tkinter import messagebox
from datetime import datetime

from SetSql import *

conn = GetConn()

class Wallet():

    def __init__(self, tempId):



        self.tempId = tempId

        p = "SELECT BALANCE FROM PERSON WHERE ID = " + str(self.tempId) + ";"
        print(p)
        cur = conn.cursor()
        cur.execute(p)
        tempBalance = cur.fetchall()[0][0]

        p = "SELECT WALLETNUM FROM PERSON WHERE ID = " + str(self.tempId) + ";"
        print(p)
        cur.execute(p)
        self.WALLETNUM = cur.fetchall()[0][0]

        self.window = tkinter.Tk()
        self.window.title("Student Wallet")
        self.window.geometry('800x800')
        self.window.geometry("+600+200") # to position the window in the center
        self.window.configure(bg = '#ADADAD')
        self.window.iconphoto(False,tkinter.PhotoImage(file='smallLOGO.png'))

        self.canv = tkinter.Canvas( width=200,height=200 ,bg="#ADADAD",highlightbackground="#ADADAD")
        self.img = tkinter.PhotoImage(file='KSU.png')
        self.canv.create_image(100,100, image=self.img)
        self.canv.pack()

        # wallet number Text
        self.lblWnum = tkinter.Label(self.window, text="Your wallet number is", font=('Helvetica', 14, 'bold'),bg="#ADADAD")
        self.lblWnum.pack()
        # wallet number
        self.lblWnum1 = tkinter.Label(self.window, text=self.WALLETNUM, font=('Helvetica', 14),bg="#ADADAD")
        self.lblWnum1.pack()

        # current balance Text
        self.lblB = tkinter.Label(self.window, text="Your balance is", font=('Helvetica', 14, 'bold'),bg="#ADADAD")
        self.lblB.pack()

        # balance
        self.lblB1 = tkinter.Label(self.window, text=tempBalance, font=('Helvetica', 14),bg="#ADADAD")
        self.lblB1.pack()

        # KSU entities
        self.listbox = tkinter.Listbox(self.window,bg="#CCCCCC")
        self.listbox.pack()
        result = cur.execute('SELECT FIRSTNAME,WALLETNUM FROM PERSON where WALLETTYPE="KSU"')

        # Receive a list of lists that hold the result
        count = 1
        for row in result.fetchall():
            name = row[0]
            wallet = row[1]
            # put in the list box
            self.listbox.insert(count, name + " " + str(wallet))

        # to wallet number
        # Label
        self.lbltransfer = tkinter.Label(self.window, text="Transfer to (wallet number)",bg="#ADADAD" )
        self.lbltransfer.pack()
        # Form
        self.txttransfer = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txttransfer.pack()

        # amount
        # Label
        self.lblamount = tkinter.Label(self.window, text="Amount",bg="#ADADAD")
        self.lblamount.pack()
        # Form
        self.txtamount = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtamount.pack()

        # pay button
        self.buttonPay = tkinter.Button(self.window, text='Pay', command=self.transferto,bg = '#4F94CD')
        self.buttonPay.pack()

        # back button
        self.buttonBack1 = tkinter.Button(self.window, text='Back', command=self.go_signup,bg = '#4F94CD')
        self.buttonBack1.pack()

        self.buttonBack = tkinter.Button(self.window, text='Logout', command=self.logout,bg = '#4F94CD')
        self.buttonBack.pack()

        self.window.mainloop()


    def isfloat(self , num):
        try:
            float(num)
            return True
        except ValueError:
            return False

    def logout(self):
        self.window.destroy()
        import signUp
        signUp.signUp()

    def go_signup(self):
        self.window.destroy()
        import signUp
        signUp.signUp()

    def go_Login(self):
        self.window.destroy()
        import logIn
        logIn.logIn()


    def transferto(self):
        if str(self.txttransfer.get()) != str(self.WALLETNUM):
            tempfloat = self.isfloat(self.txtamount.get())
            if self.txtamount.get() != "" and self.txttransfer.get() != "" and  self.txttransfer.get().isnumeric() and tempfloat :
                q = "SELECT BALANCE FROM PERSON WHERE ID = " + str(self.tempId) + ";"
                print(q)
                cur = conn.cursor()
                cur.execute(q)
                tempBamlanceFrom = float(cur.fetchall()[0][0])
                tempfrom = self.WALLETNUM
                tempAmount1 = float(self.txtamount.get())
                tempto = self.txttransfer.get()

                j = "SELECT WALLETNUM FROM PERSON WHERE WALLETNUM = " + str(tempto) + ";"
                cur.execute(j)
                print(j)
                records = cur.fetchall()
                print(records)

                if len(records) == 0 :
                    error_msg = ('No wallet exists with this number, only (digits)')
                    tkinter.messagebox.showerror('Wrong input', error_msg)
                else:

                    p = "SELECT BALANCE FROM PERSON WHERE WALLETNUM = " + str(tempto) + ";"
                    cur.execute(p)
                    tempBalanceTo = float(cur.fetchall()[0][0])

                    if tempBamlanceFrom < tempAmount1 or tempAmount1 <= 0:
                        error_msg = ('There is not enough money, only ( Positive digits)')
                        tkinter.messagebox.showerror('Wrong input', error_msg)
                    elif tempAmount1 > 0 and tempBamlanceFrom >= tempAmount1:
                        # update to
                        tempBalanceTo += tempAmount1
                        q = "UPDATE PERSON set BALANCE = " + str(tempBalanceTo) + " where WALLETNUM = " + str(tempto) + ";"
                        cur.execute(q)
                        # update from
                        tempBamlanceFrom -= tempAmount1
                        j = "UPDATE PERSON set BALANCE = " + str(tempBamlanceFrom) + " where WALLETNUM = " + str(
                            tempfrom) + ";"
                        cur.execute(j)
                        conn.commit()

                        self.lblB1['text'] = str(tempBamlanceFrom)

                        self.transactioninfo()
                        Messagepay = 'your transfer is done! '
                        tkinter.messagebox.showinfo('Transfer', Messagepay)
            else:
                error_msg = "The data entered are not correct"
                tkinter.messagebox.showerror('Wrong input', error_msg)
        else:
            error = "The data entered are not correct"
            tkinter.messagebox.showerror('Wrong input', error)
    def transactioninfo(self):
        now = datetime.now()
        # dd/mm/YY H:M:S
        DateTime = now.strftime("%d/%m/%Y %H:%M:%S")
        tempAmount = self.txtamount.get()
        tempfrom = self.WALLETNUM
        tempto = self.txttransfer.get()

        # append
        file1 = open("trnsaction.txt", "a")

        DateTime1 = repr(DateTime)
        tempAmount1 = repr(tempAmount)
        tempfrom1 = repr(tempfrom)
        tempto1 = repr(tempto)

        file1.write('Time and date:  \n' + DateTime1 + '\n')
        file1.write('The amount: \n' + tempAmount1 + '\n')
        file1.write('Wallet number of a sender: \n' + tempfrom1 + '\n')
        file1.write('Wallet number of a receiver: \n' + tempto1 + '\n')

        file1.close()


