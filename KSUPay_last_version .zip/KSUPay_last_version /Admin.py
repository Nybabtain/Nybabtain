import tkinter
from tkinter import messagebox
import uuid
from datetime import datetime
from SetSql import *

conn = GetConn()

class Admin:
    global tempWalletE
    global tempBalanceE
    global Date
    global totalBalance

    def __init__(self):
        self.window = tkinter.Tk()
        self.window.title("Admin")
        self.window.geometry('800x800')
        self.window.geometry("+600+200") # to position the window in the center
        self.window.configure(bg = '#ADADAD')
        self.window.iconphoto(False,tkinter.PhotoImage(file='smallLOGO.png'))

        self.canv = tkinter.Canvas( width=200,height=200 ,bg="#ADADAD",highlightbackground="#ADADAD")
        self.img = tkinter.PhotoImage(file='KSU.png')
        self.canv.create_image(100,100, image=self.img)
        self.canv.pack()

        # total balance Text
        self.lblTotal = tkinter.Label(self.window, text="Total balane is ", font=('Helvetica', 14, 'bold'),bg="#ADADAD")
        self.lblTotal.pack()

        q = 'SELECT sum(BALANCE) FROM PERSON WHERE WALLETTYPE = "KSU"'
        cur = conn.cursor()
        cur.execute(q)
        self.totalBalance = cur.fetchall()[0][0]
        # total balance
        self.txtTotal = tkinter.Label(self.window, text=self.totalBalance, font=('Helvetica', 14),bg="#ADADAD")
        self.txtTotal.pack()

        # add entities
        # Label
        self.lblAdd = tkinter.Label(self.window, text="Enter the KSU entity name " ,bg="#ADADAD")
        self.lblAdd.pack()
        # Form
        self.txtAdd = tkinter.Entry(self.window, width=10,bg = '#CCCCCC')
        self.txtAdd.pack()

        # submit button
        self.buttonSubmit = tkinter.Button(self.window, text='Submit ', command=self.submit,bg = '#4F94CD')
        self.buttonSubmit.pack()

        # Pay Stipends
        self.buttonStipends = tkinter.Button(self.window, text='Pay stipends ', command=self.paystipends,bg = '#4F94CD')
        self.buttonStipends.pack()

        # cash out button
        self.buttonCashOut = tkinter.Button(self.window, text='Cash out ', command=self.cashout,bg = '#4F94CD')
        self.buttonCashOut.pack()

        # Backup button
        self.buttonBackup = tkinter.Button(self.window, text='Backup', command=self.backup,bg = '#4F94CD')
        self.buttonBackup.pack()

        # back button
        self.buttonBack1 = tkinter.Button(self.window, text='Back', command=self.go_signup,bg = '#4F94CD')
        self.buttonBack1.pack()

        self.buttonlogout = tkinter.Button(self.window, text='Logout', command=self.logout,bg = '#4F94CD')

        self.buttonlogout.pack()
        self.window.mainloop()

    def submit(self):
        if self.txtAdd.get() != "":
            now = datetime.now()
            # dd/mm/YY H:M:S
            self.Date = now.strftime("%d/%m/%Y %H:%M:%S")

            UUID = uuid.uuid1()
            self.tempWalletE = int(UUID.time_low)
            q = True
            while (q):
                if (self.tempWalletE == 1000000001 or self.tempWalletE == 1000000002 or self.tempWalletE == 1000000003):
                    UUID = uuid.uuid1()
                    self.tempWalletE = int(UUID.time_low)

                else :
                    q = False

            conn.execute(
                'INSERT OR IGNORE INTO PERSON (FIRSTNAME,LASTNAME,ID,PASSWORD,EMAIL,PHONE,WALLETNUM,BALANCE,DATEANDTIME,WALLETTYPE) VALUES ("' + self.txtAdd.get() + '","","' + str(
                    self.tempWalletE) + '","","' + self.txtAdd.get() + '@ksu.edu.sa","","' + str(
                    self.tempWalletE) + '",0.0,"' + self.Date + '","KSU")')
            conn.commit()

            messagesubmit = "Add is Done!"
            tkinter.messagebox.showinfo('Add new entity', messagesubmit)
        else :
            messagesubmit = "Wrong you must enter digits or letters or both"
            tkinter.messagebox.showerror('Wrong input', messagesubmit)


    def paystipends(self):
        conn.execute('UPDATE PERSON set BALANCE = BALANCE +1000.0 where WALLETTYPE = "student"')
        conn.commit()

        messagepaystipends = 'Deposits 1000 SR to all the student Wallets is Done!'
        tkinter.messagebox.showinfo('Pay stipends', messagepaystipends)

    def cashout(self):

        conn.execute('UPDATE PERSON set BALANCE = 0.0 where WALLETTYPE = "KSU"')
        conn.commit()
        messagecashout = 'all KSU entitys balance is Zero! '
        self.txtTotal['text'] = str(0.0)
        tkinter.messagebox.showinfo('Cash out', messagecashout)



    def backup(self):
        conn.text_factory = str
        # always with data
        cur = conn.cursor()
        data = cur.execute("SELECT * FROM PERSON")

        #
        with open('backup.csv', 'w') as f:
            import csv
            writer = csv.writer(f)
            #
            writer.writerow([i[0] for i in data.description])
            writer.writerows(data)

        # message for finished backup
        MessageBackup = 'Backup is finished '
        tkinter.messagebox.showinfo('Backup', MessageBackup)

    def logout(self):
        self.window.destroy()
        import signUp
        signUp.signUp()

    def go_signup(self):
        self.window.destroy()
        import signUp
        signUp.signUp()
