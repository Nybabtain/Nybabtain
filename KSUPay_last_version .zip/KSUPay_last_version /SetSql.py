import sqlite3

def GetConn():
    conn = sqlite3.connect("KSUPay.db")
    SetupSQL(conn)
    return conn

def SetupSQL(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS PERSON
        (FIRSTNAME   TEXT   NOT NULL,
        LASTNAME    TEXT   NOT NULL,
        ID  TEXT  PRIMARY KEY NOT NULL,
        PASSWORD    TEXT   NOT NULL,
        EMAIL       TEXT   NOT NULL,
        PHONE       INT    NOT NULL,
        WALLETNUM   INT,
        BALANCE     DOUBLE,
        DATEANDTIME DATE   ,
        WALLETTYPE  TEXT   );''')
    # admin
    conn.execute('''INSERT OR IGNORE INTO PERSON (FIRSTNAME,LASTNAME,ID,PASSWORD,EMAIL,PHONE,WALLETNUM,BALANCE,WALLETTYPE) VALUES ("admin","","1000000000","admin123","admin@ksu.edu.sa","",NULL,NULL,"admin")''')

    #bookstor    INSERT INTO
    conn.execute('''INSERT OR IGNORE INTO PERSON (FIRSTNAME,LASTNAME,ID,PASSWORD,EMAIL,PHONE,WALLETNUM,BALANCE,WALLETTYPE) VALUES ("Bookstore","","1000000001","","bookstore@ksu.edu.sa","","1000000001",0.0,"KSU")''')
    #housing
    conn.execute('''INSERT OR IGNORE INTO PERSON (FIRSTNAME,LASTNAME,ID,PASSWORD,EMAIL,PHONE,WALLETNUM,BALANCE,WALLETTYPE) VALUES ("Housing","","1000000002","","housing@ksu.edu.sa","","1000000002",0.0,"KSU")''')
    #restraunt
    conn.execute('''INSERT OR IGNORE INTO PERSON (FIRSTNAME,LASTNAME,ID,PASSWORD,EMAIL,PHONE,WALLETNUM,BALANCE,WALLETTYPE) VALUES ("Restaurant","","1000000003","","restaurant@ksu.edu.sa","","1000000003",0.0,"KSU")''')
    conn.commit()
