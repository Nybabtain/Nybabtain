import tkinter
from tkinter import messagebox
from SetSql import *





conn = GetConn()
class logIn:
    def __init__(self):


        self.window = tkinter.Tk()
        self.window.title("Login")
        self.window.geometry('800x800')

        self.window.configure(bg = '#ADADAD')
        self.window.iconphoto(False,tkinter.PhotoImage(file='smallLOGO.png'))

        self.canv = tkinter.Canvas( width=200,height=200 ,bg="#ADADAD",highlightbackground="#ADADAD")
        self.img = tkinter.PhotoImage(file='KSU.png')
        self.canv.create_image(100,100, image=self.img)
        self.canv.pack()

        # First Text
        self.lblMain = tkinter.Label(self.window, text="KSUPay", font=('Helvetica', 16, 'bold'), bg='#ADADAD')
        self.lblMain.pack()

        # ID
        # Label
        self.lblID = tkinter.Label(self.window, text="ID", bg="#ADADAD")
        self.lblID.pack()
        # Form
        self.txtID = tkinter.Entry(self.window, width=10,bg='#CCCCCC')
        self.txtID.pack()

        # Password
        # Label
        self.lblPass = tkinter.Label(self.window, text="Password", bg="#ADADAD")
        self.lblPass.pack()
        # Form
        self.txtPass = tkinter.Entry(self.window, width=10,bg='#CCCCCC')
        self.txtPass.pack()

        # if admin go to admin class if not go to wallet class
        self.buttonLogin = tkinter.Button(self.window, text='Login', command=self.validation,bg = '#4F94CD')
        self.buttonLogin.pack()

        self.window.mainloop()

    def go_signup(self):
        self.window.destroy()
        import signUp
        signUp.signUp()

    def go_wallet(self , a):
        self.window.destroy()
        import Wallet
        Wallet.Wallet(a)

    def go_admin(self):
        self.window.destroy()
        import Admin
        Admin.Admin()

    def find(self):
        tempID = self.txtID.get()
        tempPass = self.txtPass.get()

        p = "SELECT ID FROM PERSON WHERE ID = " + str(tempID) + ";"
        cur = conn.cursor()
        cur.execute(p)
        print(p)
        records = cur.fetchall()
        print(records)
        if len(records)==0:
            error = "You are not registered"
            tkinter.messagebox.showerror('Wrong input', error)
        else:
            q = "SELECT PASSWORD FROM PERSON WHERE ID = " + str(tempID) + ";"
            cur.execute(q)
            tempPass1 = cur.fetchall()[0][0]
            if str(tempPass) == str(tempPass1):
                q = "SELECT WALLETTYPE FROM PERSON WHERE ID = " + str(tempID) + ";"
                cur.execute(q)
                WALLETTYPE = cur.fetchall()[0][0]
                if WALLETTYPE=="admin":
                    self.go_admin()
                else:
                    self.go_wallet(tempID)
            else:
                error_msg = 'Wrong Password or ID'
                tkinter.messagebox.showerror('Wrong input', error_msg)

    def validation(self):
        error_msg = ""
        if not self.txtID.get().isnumeric():
            error_msg += "ID must be all digits\n"
        if len(self.txtID.get()) != 10:
            error_msg += "ID must 10 digits\n"
        if len(self.txtID.get()) < 1:
            error_msg += "ID cant be empty \n"
        if len(self.txtPass.get()) < 6:
            error_msg += "password must at leats 6 digits pr letters\n"
        if len(self.txtPass.get()) < 1:
            error_msg += "Password cant be empty \n"
        if error_msg == "":
            self.find()

            self.txtID.delete(0, "end")
            self.txtPass.delete(0, "end")
        else:
            tkinter.messagebox.showerror('Wrong input', error_msg)
